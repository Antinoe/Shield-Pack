using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace ShieldPack.Items.Equipables.Accessories.Shields
{
	[AutoloadEquip(EquipType.Shield)]
	public class HeroShield : ModItem
	{

		public override void SetDefaults()
		{

			Item.width = 26;
			Item.height = 26;
			Item.value = 15000;
			Item.rare = 8;
			Item.accessory = true;
			Item.defense = 8;
		}

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hero Shield");
			Tooltip.SetDefault("Grants immunity to most debuffs\nGrants immunity to knockback and fire blocks\nProlonged after hit invicibility");
		}

		public override void UpdateEquip(Player p)
		{
			p.noKnockback = true;
			//p.paladinBuff = true;
			p.fireWalk = true;
			p.longInvince = true;
			p.buffImmune[44] = true; //Frostburn
			p.buffImmune[46] = true; //Chilled
			p.buffImmune[47] = true; //Frozen
			p.buffImmune[20] = true; //Poisoned
			p.buffImmune[22] = true; //Darkness
			p.buffImmune[24] = true; //Fire
			p.buffImmune[23] = true; //Cursed
			p.buffImmune[30] = true; //Bleeding
			p.buffImmune[31] = true; //Confused
			p.buffImmune[32] = true; //Slowed
			p.buffImmune[33] = true; //Weak
			p.buffImmune[35] = true; //Silenced
			p.buffImmune[36] = true; //Broken Armor
			p.buffImmune[69] = true; //Ichor
			p.buffImmune[70] = true; //Venom
			p.buffImmune[80] = true; //Black Out
		}
		public override void AddRecipes()
		{
			CreateRecipe(1)
				.AddIngredient(null, "HolyShield", 1)
				.AddIngredient(ItemID.AnkhShield, 1)
				.AddTile(TileID.Anvils)
				.Register();
		}
	}
}
