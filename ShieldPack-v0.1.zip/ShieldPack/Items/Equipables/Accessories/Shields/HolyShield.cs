using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace ShieldPack.Items.Equipables.Accessories.Shields
{
	[AutoloadEquip(EquipType.Shield)]
	public class HolyShield : ModItem
	{
		public override void SetDefaults()
		{

			Item.width = 26;
			Item.height = 26;
			Item.value = 12000;

			Item.rare = 7;
			Item.accessory = true;
			Item.defense = 6;
		}

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Holy Shield");
			Tooltip.SetDefault("Prolonged after hit invincibility");
		}

		public override void UpdateEquip(Player player)
		{
			player.longInvince = true;
		}
		public override void AddRecipes()
		{
			CreateRecipe(1)
				.AddIngredient(ItemID.PaladinsShield, 1)
				.AddIngredient(ItemID.CrossNecklace, 1)
				.AddTile(TileID.Anvils)
				.Register();
		}
	}
}
